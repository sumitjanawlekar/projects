package com.sumit.pojo;

public class Admin {

	private String adminLogin;
	private String serviceCenter;

}
